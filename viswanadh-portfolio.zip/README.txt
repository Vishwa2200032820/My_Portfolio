# Viswanadh Portfolio

A responsive animated portfolio built with plain HTML, CSS and JavaScript.

## Files
- index.html
- style.css
- script.js

## Run locally
Open `index.html` in a browser.

## Netlify
Drag the entire folder into Netlify Drop, or connect the GitHub repository.

## Personalise
1. Replace the LinkedIn and GitHub placeholder links in `index.html`.
2. Add your profile photo if desired.
3. Add project GitHub/live-demo links to the project cards.
4. Add certificate files/images if you want downloadable certificates.
